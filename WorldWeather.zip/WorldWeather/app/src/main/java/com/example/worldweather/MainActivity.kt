package com.example.worldweather

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.KeyEvent.DispatcherState
import android.widget.Toast
import com.example.worldweather.databinding.ActivityMainBinding
import com.squareup.picasso.Picasso
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityMainBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        binding.mainButton.setOnClickListener {
            if(binding.userField.text.toString().trim().equals(""))
                Toast.makeText(this, "Введите город!", Toast.LENGTH_LONG).show()
            else {
                var city: String = binding.userField.text.toString()
                var key: String = "f835c2b6d9324e8cdb10d6892529ae4b"
                var url: String = "https://api.openweathermap.org/data/2.5/weather?q=$city&appid=$key&units=metric&lang=ru"
                GlobalScope.launch(Dispatchers.IO) {
                   val apiResponse = URL(url).readText()
                   val weather = JSONObject(apiResponse).getJSONArray("weather")
                   val desc = weather.getJSONObject(0).getString("description")
                    val iconId = weather.getJSONObject(0).getString("icon")
                    val main = JSONObject(apiResponse).getJSONObject("main")
                    val temp = main.getString("temp")
                    val imgURL = "https://api.openweathermap.org/img/w/$iconId.png"

                    withContext(Dispatchers.Main) {
                        binding.resultimport.text = "Температура: $temp\n$desc"
                        Picasso.get().load(imgURL).resize(400,400).into(binding.imageWeather)
                    }
                }
            }
        }
    }
}