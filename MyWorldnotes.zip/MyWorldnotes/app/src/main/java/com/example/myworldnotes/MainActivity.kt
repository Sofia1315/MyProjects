package com.example.myworldnotes

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.SparseBooleanArray
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import com.example.myworldnotes.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        var itemList = arrayListOf<String>()
        var adapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, itemList)
        binding.spisok.adapter = adapter
        binding.add.setOnClickListener {
            itemList.add(binding.editTextText5.text.toString())
            adapter.notifyDataSetChanged()
            binding.editTextText5.text.clear()


        }
        binding.delete.setOnClickListener {
            val position: SparseBooleanArray = binding.spisok.checkedItemPositions
            var item = binding.spisok.count - 1
            while (item >= 0) {
                if (position[item]) {
                    itemList.removeAt(item)
                }
                item--
            }
            position.clear()
            adapter.notifyDataSetChanged()
        }
        binding.clear.setOnClickListener{
            itemList.clear()
            adapter.notifyDataSetChanged()
        }
    }
}